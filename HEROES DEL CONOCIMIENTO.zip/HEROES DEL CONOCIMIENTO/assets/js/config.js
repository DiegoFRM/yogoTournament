var timeUser
var config = {
    theme: "tournament2018",
    fonts: "custom_fonts",
    includeOptionsLetters:true,
    NumberOptions:4,
    timeLimit:40,
    testMode:true,
    instructions:'Hola Bienvenido a tu prueba de "Yogome Tournament" tienes un tiempo de <span>4 minutos</span> para empezar da click en el botón de OK <p><span>¡BUENA SUERTE!</span></p>',
    resultsScene:''
}